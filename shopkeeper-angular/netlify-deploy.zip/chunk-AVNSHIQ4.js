import{a as y}from"./chunk-6HYLORXF.js";import{c as d,d as b,h as x}from"./chunk-M2BBOT7G.js";import{Q as g,W as f}from"./chunk-73ZKOIMN.js";var S=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"],u=class h{svg(e,t={}){let s=t.module??1.5,r=t.height??40,i=String(e??"");if(!i)return"";let c=[104],l=104;for(let p=0;p<i.length;p++){let a=i.charCodeAt(p)-32;(a<0||a>94)&&(a=0),c.push(a),l+=a*(p+1)}c.push(l%103),c.push(106);let n=0,o="";for(let p of c){let a=S[p],m=!0;for(let $ of a){let v=Number($)*s;m&&(o+=`<rect x="${n.toFixed(2)}" y="0" width="${v.toFixed(2)}" height="${r}"/>`),n+=v,m=!m}}return`<svg width="${n.toFixed(2)}" height="${r}" viewBox="0 0 ${n.toFixed(2)} ${r}" xmlns="http://www.w3.org/2000/svg" fill="#000">${o}</svg>`}generate(e){let t=new Set(e),s;do s=String(Math.floor(2e11+Math.random()*799999999999));while(t.has(s));return s}static \u0275fac=function(t){return new(t||h)};static \u0275prov=g({token:h,factory:h.\u0275fac,providedIn:"root"})};var w=class h{store=f(x);barcode=f(u);toast=f(y);money(e,t=!0){let s=b(d(e)),r=Math.abs(s).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2});return(s<0?"-":"")+(t?"\u20B9 ":"")+r}esc(e){return String(e??"").replace(/[&<>"]/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[t])}invoice(e){let t=this.store.settings(),s=e.partyId?this.store.getParty(e.partyId):null,r=t.taxEnabled,i=b(Math.max(0,d(e.total)-d(e.paid))),c=(e.lines??[]).map((o,p)=>{let a=d(o.qty)*d(o.rate),m=r?a*d(o.taxRate)/100:0;return`<tr>
        <td>${p+1}</td>
        <td>${this.esc(o.name)}${o.description?'<div class="mut">'+this.esc(o.description)+"</div>":""}</td>
        <td>${this.esc(o.hsn??"")}</td>
        <td class="r">${d(o.qty)} ${this.esc(o.unit??"")}</td>
        <td class="r">${this.money(o.rate,!1)}</td>
        <td class="r">${this.money(a,!1)}</td>
        ${r?`<td class="r">${d(o.taxRate)}%</td>`:""}
        <td class="r">${this.money(a+m,!1)}</td>
      </tr>`}).join(""),l=r?8:7,n=`<!doctype html><html><head><meta charset="utf-8"><title>${this.esc(e.number)}</title>
      <style>
        *{box-sizing:border-box}body{font:13px/1.5 Arial,Helvetica,sans-serif;color:#111;margin:0;padding:24px}
        h1{font-size:20px;margin:0}.head{display:flex;justify-content:space-between;border-bottom:2px solid #222;padding-bottom:10px;margin-bottom:12px}
        .mut{color:#666;font-size:11px}table{width:100%;border-collapse:collapse;margin-top:10px}
        th,td{border:1px solid #ccc;padding:6px 8px;text-align:left}.r{text-align:right}
        thead th{background:#f2f4f8}tfoot td{font-weight:700}.title{font-size:16px;font-weight:800;margin:6px 0}
        .two{display:flex;justify-content:space-between;gap:20px;margin-top:8px}
        @media print{body{padding:0}}
      </style></head><body>
      <div class="head">
        <div><h1>${this.esc(t.businessName)}</h1><div class="mut">${this.esc(t.address??"")}</div>
          <div class="mut">${t.gstin?"GSTIN: "+this.esc(t.gstin):""} ${t.phone?" \xB7 "+this.esc(t.phone):""}</div></div>
        <div style="text-align:right"><div class="title">Invoice</div><div>#${this.esc(e.number)}</div><div class="mut">${this.esc(e.date)}</div></div>
      </div>
      <div class="two"><div><strong>Bill To:</strong><br>${this.esc(s?.name??"Cash Sale")}<br>
        <span class="mut">${this.esc(s?.phone??"")} ${s?.gstin?"\xB7 GSTIN "+this.esc(s.gstin):""}</span></div></div>
      <table><thead><tr><th>#</th><th>Item</th><th>HSN</th><th class="r">Qty</th><th class="r">Rate</th><th class="r">Taxable</th>${r?'<th class="r">GST</th>':""}<th class="r">Amount</th></tr></thead>
        <tbody>${c}</tbody>
        <tfoot>
          <tr><td colspan="${l-1}" class="r">Total</td><td class="r">${this.money(e.total,!1)}</td></tr>
          <tr><td colspan="${l-1}" class="r">Paid</td><td class="r">${this.money(e.paid,!1)}</td></tr>
          <tr><td colspan="${l-1}" class="r">Balance Due</td><td class="r">${this.money(i,!1)}</td></tr>
        </tfoot></table>
      ${t.upiId?`<p class="mut">Pay via UPI: <strong>${this.esc(t.upiId)}</strong></p>`:""}
      ${t.terms?`<p class="mut"><strong>Terms:</strong> ${this.esc(t.terms)}</p>`:""}
      <p style="text-align:right;margin-top:40px">For <strong>${this.esc(t.signatureName||t.businessName)}</strong><br><br>Authorised Signatory</p>
      <script>window.onload=function(){window.print()}<\/script></body></html>`;this.open(n)}labels(e){let t=this.store.settings(),s="";for(let{item:i,copies:c}of e){let l=this.money(i.salePrice)+(i.unit?" / "+this.esc(i.unit):"");for(let n=0;n<c;n++)s+=`<div class="label">
          <div class="l-shop">${this.esc(t.businessName)}</div>
          <div class="l-name">${this.esc(i.name)}${i.brand?" \xB7 "+this.esc(i.brand):""}</div>
          ${this.barcode.svg(i.barcode??"",{module:1.5,height:34})}
          <div class="l-code">${this.esc(i.barcode??"")}</div>
          <div class="l-price">${l}</div>
        </div>`}let r=`<!doctype html><html><head><meta charset="utf-8"><title>Barcode Labels</title><style>
      *{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif}
      .sheet{display:flex;flex-wrap:wrap;gap:4px;padding:6px}
      .label{width:150px;height:100px;border:1px dashed #bbb;padding:4px 6px;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center;page-break-inside:avoid}
      .l-shop{font-size:9px;color:#333;font-weight:700;text-transform:uppercase;width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
      .l-name{font-size:10px;margin:1px 0 2px;width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
      svg{display:block;margin:0 auto}.l-code{font-size:9px;letter-spacing:1px;margin-top:1px}.l-price{font-size:13px;font-weight:800;margin-top:2px}
      @media print{.label{border:none}@page{margin:6mm}}
    </style></head><body><div class="sheet">${s}</div><script>window.onload=function(){window.print()}<\/script></body></html>`;this.open(r)}open(e){let t=window.open("","_blank");if(!t){this.toast.error("Pop-up blocked \u2014 allow pop-ups to print.");return}t.document.write(e),t.document.close()}static \u0275fac=function(t){return new(t||h)};static \u0275prov=g({token:h,factory:h.\u0275fac,providedIn:"root"})};export{u as a,w as b};
